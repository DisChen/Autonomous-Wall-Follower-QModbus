Adapted entirely from ModbusIP_ESP8266 Andre Sarmento Library

Needs Modbus.h library from https://github.com/andresarmento/modbus
